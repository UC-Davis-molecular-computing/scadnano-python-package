from scadnano.scadnano import *
current_version = "0.8.1"