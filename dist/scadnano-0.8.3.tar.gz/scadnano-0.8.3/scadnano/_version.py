"""Version information."""
# taken from https://stackoverflow.com/questions/17583443/what-is-the-correct-way-to-share-package-version-with-setup-py-and-the-package/17626524#17626524

# The following line *must* be the last in the module, exactly as formatted:
__version__ = "0.8.3"
